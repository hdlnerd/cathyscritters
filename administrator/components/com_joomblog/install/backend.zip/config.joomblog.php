<?php
/**
* JoomBlog component for Joomla 1.6 & 1.7
* @version $Id: config.joomblog.php 2011-03-16 17:30:15
* @package JoomBlog
* @subpackage config.joomblog.php
* @author JoomPlace Team
* @Copyright Copyright (C) JoomPlace, www.joomplace.com
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

if (!defined('JOOMBLOG_CONFIG_CLASS'))
{
	define('JOOMBLOG_CONFIG_CLASS', 1);

	class JB_Configuration
	{
		var $_configString = "";
		var $_tableName = "#__joomblog_config";
		var $useBBCode = "1";
		var $useFeed = "1";
		var $notifyAdmin = "0";
		var $notifyEmail = "";
		var $dateFormat = "%d %B %Y, %H:%M";
		var $numEntry = "10";
		var $avatar = "none";
		var $textWrap = "75";
		var $processMambots = "0";
		var $useComment = "1";
		var $useJomComment = "0";
		var $useDraganddrop = "0";
		var $sectionid = "1";
		var $template = "default";
		var $overrideTemplate = "0";
		var $frontOrderby = "ordering";
		var $postGroup= "Manager,Administrator,Registered,Author,Editor,Publisher,Shop Suppliers,Customer Group,Super Users";
		var $adminPostGroup = "";
		var $adminPublishControlGroup = "";
		var $publishControlGroup= "Manager,Administrator,Registered,Author,Editor,Publisher,Shop Suppliers,Customer Group,Super Users";
		var $postUsers = "";
		var $frontpageToolbar = "1";
		var $allowedUser = "";
		var $useMCEeditor = "1";
		var $catid = "0";
		var $managedSections = "0";
		var $postSection = "0";
		var $showCBProfile = "";
		var $avatarWidth = "160";
		var $avatarHeight = "160";
		var $maxFileSize = "2";
		var $smfPath = "";
		var $linkAvatar = "0";
		var $imgFolderRestrict = "0";
		var $useRSSFeed = "1";
		var $rssFeedLimit	= '20';
		var $pingTechnorati = "0";
		var $useImageUpload = "1";
		var $useFullName = "0";
		var $introLength = "400";
		var $useIntrotext = "1";
		var $defaultPublishStatus = "1";
		var $mambotFrontpage = "0";
		var $necessaryReadmore = "1";
		var $disableReadMoreTag = "0";
		var $readMoreLink = "read more...";
		var $replacements_array = array();
		var $language = "english.php";
		var $allowedPosters = "";
		var $allowedPublishers = "";
		var $extraPostGroups = "";
		var $extraPublishGroups = "";
		var $limitComment = "20";
		var $allowModerateComment = "0";
		var $useCommentCaptcha = "1";
		var $useCommentCaptchaRegisteredUsers = "0";
		var $useCommentOnlyRegisteredUsers = "0";
		var $allowCategorySelection = "1";
		var $enableBackLink = "1";
		var $enablePdfLink = "1";
		var $enablePrintLink = "1";
		var $enableJCDashboard = "0";
		var $enableUserCreateTags   = "1";
		var $enableAllVideoBot    = "0";
		var $mainBlogTitle = "JoomBlog";
		var $mainBlogDesc = "Description of joomblog";
		var $useFeedBurner	= '0';
		var $useFeedBurnerURL	= "";
		var $userUseFeedBurner	= '0';
		var $adminEmail			= '';
		var $allowNotification	= '';
		var $viewEntry = '1';
		var $viewIntro = '1';
		var $viewComments = '1';
		var $anchorReadmore	= '0';
		var $allowDefaultTags	= '0';
		var $autoReadmorePCount = '3';
		var $disallowedPosters	= '';
		var $categoryDisplay	= '1';
		var $modulesDisplay	= '0';
		var $notifyCommentAdmin = '1';
		var $notifyCommentAuthor = '1';
		var $showIcons = '1';
		var $showTabs = '1';
		var $showPanel = '1';
		var $useDisqus = '0';
		var $disqusSubDomain = '';
		var $useAddThis = '0';
		var $addThisName = '';
		var $showPosts = 1;
		var $showBlogs = 1;
		var $showSearch = 1;
		var $showFeed = 1;
		var $showProfile = 1;
		var $showAddPost = 1;
		var $showBloggers = 1;
		var $showCategories = 1;
		var $showArchive = 1;
		var $showTags = 1;
		var $titlePosts = 'Posts';
		var $titleBlogs = 'Blogs';
		var $titleSearch = 'Search';
		var $titleFeed = 'Feed';
		var $titleProfile = 'Profile';
		var $titleAddPost = 'Add Post';
		var $titleBloggers = 'Bloggers';
		var $titleCategories = 'Categories';
		var $titleArchive = 'Archive';
		var $titleTags = 'Tags';
		var $firstPosition = '1';
		var $secondPosition = '2';
		var $thirdPosition = '3';
		var $fourthPosition = '4';
		var $fifthPosition = '5';
		var $sixthPosition = '6';
		var $seventhPosition = '7';
		var $eighthPosition = '8';
		var $ninthPosition = '9';
		var $tenthPosition = '10';
		var $BloggerRecentPosts = 5;
		var $CategoriesRecentPosts = 5;
		var $showUserLink = '1';
		
		var $integrJoomSoc = '0';
		var $autoapproveblogs='1';
		
		function JB_Configuration()
		{
			$mainframe	=& JFactory::getApplication();
			$db	=& JFactory::getDBO();
			
			$db->setQuery("SELECT params FROM #__extensions WHERE name='com_joomblog' AND element='com_joomblog'");
			$this->_configString = $db->loadResult();
			
			/* BAD WAY
			$db->setQuery("SELECT rules FROM #__assets WHERE name = 'com_joomblog' ");
			if($db->loadResult() == "{}" || !$db->loadResult()){
				$db->setQuery('UPDATE #__assets SET rules=\'{"core.admin":{"1":0,"6":0,"7":0,"2":0,"3":0,"4":0,"5":0,"10":0,"12":0,"8":0},"core.manage":{"1":0,"6":0,"7":0,"2":0,"3":0,"4":0,"5":0,"10":0,"12":0,"8":0},"core.create":{"1":1,"6":1,"7":1,"2":1,"3":1,"4":1,"5":1,"10":1,"12":1,"8":0},"core.delete":{"1":1,"6":1,"7":1,"2":1,"3":1,"4":1,"5":1,"10":1,"12":1,"8":0},"core.edit":{"1":1,"6":1,"7":1,"2":1,"3":1,"4":1,"5":1,"10":1,"12":1,"8":0},"core.edit.state":{"1":1,"6":1,"7":1,"2":1,"3":1,"4":1,"5":1,"10":1,"12":1,"8":0},"core.edit.own":{"1":1,"6":1,"7":1,"2":1,"3":1,"4":1,"5":1,"10":1,"12":1,"8":0}}\' WHERE name = "com_joomblog" ');
				$db->query();
			}
						
			if (!$this->_configString)
			{			
				$default_vars = get_object_vars($this);
				$this->_configString = "";
				
				foreach ($default_vars as $name => $value)
				{
					if (substr($name, 0, 1) != "_")
						$this->_configString .= "\$$name=\"" . strval($value) . "\";\n";
				}
				
				$db->setQuery("INSERT INTO $this->_tableName SET value='$this->_configString',name='all'");
				$db->query();
			}*/

			$cfg = json_decode($this->_configString);
			
			foreach ($cfg as $key=>$val) {
				$this->$key = $val;
			}
			
			if($this->useJomComment)
			{			
				$db->setQuery("SELECT count(*) FROM #__extensions WHERE `element`='com_jomcomment'");
				$this->useJomComment = strval($db->loadResult());
			}
			
			if($this->useDraganddrop)
			{			
				$db->setQuery("SELECT count(*) FROM #__extensions WHERE `element`='com_joomdragdrop'");
				$this->useDraganddrop = strval($db->loadResult());
			}
					
			$this->replacements_array = array();
			$replacements = "ï¿½?|A, Ã‚|A, Ä‚|A, Ã„|A, Ä†|C, Ã‡|C, ÄŒ|C, ÄŽ|D, ï¿½?|D, Ã‰|E, ï¿½?|E, Ã‹|E, Äš|E, Ã?|I, ÃŽ|I, Ä¹|L, ï¿½?|N, Å‡|N, Ã“|O, Ã”|O, ï¿½?|O, Ã–|O, Å”|R, ï¿½?|R, Å |S, Åš|O, Å¤|T, Å®|U, Ãš|U, Å°|U, Ãœ|U, Ã?|Y, Å½|Z, Å¹|Z, Ã¡|a, Ã¢|a, ï¿½?|a, Ã¤|a, Ä‡|c, Ã§|c, Ä?|c, Ä?|d, Ä‘|d, Ã©|e, Ä™|e, Ã«|e, Ä›|e, Ã­|i, Ã®|i, Äº|l, Å„|n, ï¿½?|n, Ã³|o, Ã´|o, Å‘|o, Ã¶|o, Å¡|s, Å›|s, Å™|r, Å•|r, Å¥|t, Å¯|u, Ãº|u, Å±|u, Ã¼|u, Ã½|y, Å¾|z, Åº|z, Ë™|-, ÃŸ|ss, Ä„|A, Âµ|u, Ã¥|a, Ã…|A, Ã¦|ae, Ã†|AE, Å“|ce, Å’|CE, А|A, а|a, Б|B, б|b, В|V, в|v, Г|G, г|g, Д|D, д|d, Е|E, е|e, Ж|Zh, ж|zh, З|Z, з|z, И|I, и|i, Й|Y, й|y, К|K, к|k, Л|L, л|l, М|M, м|m, Н|N, н|n, О|O, о|o, П|P, п|p, Р|R, р|r, С|S, с|s, Т|T, т|t, У|U, у|u, Ф|F, ф|f, Х|Ch, х|ch, Ц|Ts, ц|ts, Ч|Ch, ч|ch, Ш|Sh, ш|sh, Щ|Sch, щ|sch, Ы|I, ы|i, Э|E, э|e, Ю|U, ю|iu, Я|Ya, я|ya, Ъ| , ъ| , Ь| , ь|";
	        $items = explode(',', $replacements);
	        foreach ($items as $item){
	            @list($src, $dst) = explode('|', trim($item));
	            $this->replacements_array[trim($src)] = trim($dst);
	        }
	        
			if(empty($this->dateFormat)){
				$this->dateFormat = '%b %d, %Y';
			}
			
			/* BAD WAY
			$data = JRequest::get('post');
			
			if (isset($data['rules'])) {
				jimport('joomla.access.rules');
				$rules = new JRules($data['rules']);
				$db->setQuery("UPDATE #__assets SET rules='".(string)$rules."' WHERE name = 'com_joomblog' ");
				$db->query();
			}*/
		}
		
		function get($varname, $default = "0") 
		{
			if (isset ($this->$varname)) 
			{
				return str_replace('%%', '$' , $this->$varname);
			}
			else
			{
				return $default;
			}
		}
		
		function saveUsingClassVars()
		{
			$db				=& JFactory::getDBO();
			
			$this->_configString = "";
			$default_vars = get_object_vars($this);
			foreach ($default_vars as $name => $value)
			{
				if (substr($name, 0, 1) != "_")
					$this->_configString .= "\$$name=\"" . strval($value) . "\";\n";
			}
			$db->setQuery("INSERT INTO $this->_tableName SET value='$this->_configString',name='all' ON DUPLICATE KEY UPDATE value='$this->_configString'");
			$db->query();
		}
		
		function save()
		{
			$db		=& JFactory::getDBO();
			$config = "";
			$this->_configString = "";
			$objvars = get_object_vars ($this);
			
			$config = json_encode($objvars);

			/* BAD WAY
			foreach($objvars as $key => $val)
			{
				if($key{0} != '_' && $key !='db')
				{
				  if(isset($_POST[$key])){
				        $val = $_POST[$key];
					}else{
					    $val = "0";
					}

					if (is_array($val)) {
						$ls = implode(",", $val);
						$config .= "\$$key= \"$ls\";\n";
					} else{
						$val	= str_replace("$" , "\\\\$" , $val );
						$config .= "\$$key=\"$val\";\n";
					}
				}
			} */

			jbClearCache();
			//$config = addslashes($config);
			$db->setQuery("UPDATE #__extensions SET params=".$db->Quote($config)." WHERE element='com_joomblog'");
			$db->query();
		}
		
		function getReplacements(){}
	}
}
?>
